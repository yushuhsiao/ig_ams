InstallUtilLib.dll is copied from %systemroot%\Microsoft.NET\Framework64\v4.0.30319\ on a x64 Windows operating system. 

Fix64bitInstallUtilLib.js automates the modification of InstallUtil in the msi file.