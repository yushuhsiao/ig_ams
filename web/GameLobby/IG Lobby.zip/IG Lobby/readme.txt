IG.Lobby.LC、IG.Lobby.TG、IG.Lobby.VA 都依賴 IG.Dal
請先用 Visual Studio 開啟 IG.Dal 並建置一次
IG.Lobby.LC 等大廳才能建置成功

IG.Lobby.LC：LiveCasino Lobby
IG.Lobby.TG：VideoArcade Lobby
IG.Lobby.VA：TabletopGames Lobby
IG.Dal：ADO.NET 實體資料模型
