﻿
namespace IG.Lobby.LC.Models
{
    public enum ApiNoticeType
    {
        Message = 0,
        Success = 1,
        Error = 2,
        Warning = 3,
        Alert = 4
    }
}
